from pygooglenews import GoogleNews
import pandas as pd

gn = GoogleNews()

top = gn.top_news()

business = gn.topic_headlines('business')


headquaters = gn.geo_headlines('San Fran')
search = gn.search('MSFT -APPL', when = '6m')

search = gn.search('data science')

df = pd.DataFrame(search['entries'])

for item in search['entries']:
    print(item)


df.to_csv('news.csv', index=False, encoding="utf-8")
#print(search)